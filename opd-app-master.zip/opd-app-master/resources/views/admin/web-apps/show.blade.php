<x-admin-layout>
    <x-slot name="header">
        Detail Aplikasi
    </x-slot>

    <!-- Main Container -->
    <div class="space-y-8">
        
        <!-- Breadcrumb & Actions -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center text-sm font-medium text-gray-500 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400">
                            <i class="fa-solid fa-house w-4 h-4 mr-2 flex items-center justify-center"></i>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fa-solid fa-chevron-right w-6 h-6 text-gray-400 flex items-center justify-center"></i>
                            <a href="{{ route('admin.web-apps.index') }}" class="ml-1 text-sm font-medium text-gray-500 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400 md:ml-2">Data Aplikasi</a>
                        </div>
                    </li>
                    <li aria-current="page">
                        <div class="flex items-center">
                            <i class="fa-solid fa-chevron-right w-6 h-6 text-gray-400 flex items-center justify-center"></i>
                            <span class="ml-1 text-sm font-medium text-gray-800 dark:text-zinc-200 md:ml-2">{{ Str::limit($webApp->nama_web_app, 20) }}</span>
                        </div>
                    </li>
                </ol>
            </nav>
            
            <a href="{{ route('admin.web-apps.index') }}" class="inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-zinc-700 shadow-sm text-sm font-medium rounded-lg text-gray-700 dark:text-zinc-300 bg-white dark:bg-zinc-900 hover:bg-gray-50 dark:hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors">
                <i class="fa-solid fa-arrow-left w-4 h-4 mr-2 text-gray-500 flex items-center justify-center"></i>
                Kembali
            </a>
        </div>

        <!-- Hero Card (Blue-Cyan Theme - Compact) -->
        <div class="relative bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-sky-100/50 dark:border-zinc-800 p-5 hover:shadow-lg transition-all duration-300 overflow-hidden">
            <!-- Subtle Wave Background -->
            <div class="absolute inset-0 opacity-5 dark:opacity-[0.03]">
                <div class="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-cyan-400 via-sky-300 to-transparent"></div>
            </div>

            <div class="relative z-10">
                <!-- Top Badge (Date only) -->
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
                        <i class="fa-regular fa-calendar w-3 h-3 mr-1 flex items-center justify-center"></i>
                        {{ $webApp->created_at->format('d M Y') }}
                    </span>
                </div>

                <!-- Main Content Grid (2x2 Compact) -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    
                    <!-- App Name -->
                    <div class="flex items-center gap-4 group">
                        <div class="relative flex-shrink-0">
                            <div class="absolute inset-0 bg-sky-400 rounded-xl blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
                            <div class="relative w-12 h-12 bg-gradient-to-br from-sky-400 via-sky-500 to-blue-500 rounded-xl flex items-center justify-center shadow-md ring-2 ring-sky-50 group-hover:scale-105 transition-transform">
                                <i class="fa-solid fa-globe w-6 h-6 text-white flex items-center justify-center"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-xs font-medium text-slate-400 uppercase tracking-wider">Nama Aplikasi</p>
                            <h1 class="text-lg font-bold text-slate-800 dark:text-white tracking-tight leading-tight truncate">{{ $webApp->nama_web_app }}</h1>
                        </div>
                    </div>

                    <!-- OPD -->
                    <div class="flex items-center gap-4 group">
                        <div class="relative flex-shrink-0">
                            <div class="absolute inset-0 bg-cyan-400 rounded-xl blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
                            <div class="relative w-12 h-12 bg-gradient-to-br from-cyan-400 via-sky-500 to-sky-600 rounded-xl flex items-center justify-center shadow-md ring-2 ring-cyan-50 group-hover:scale-105 transition-transform">
                                <i class="fa-solid fa-building w-6 h-6 text-white flex items-center justify-center"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-xs font-medium text-slate-400 uppercase tracking-wider">OPD</p>
                            <h3 class="text-base font-bold text-slate-800 dark:text-white tracking-tight truncate">{{ $webApp->opd->nama_opd }}</h3>
                        </div>
                    </div>

                    <!-- Pengelola -->
                    <div class="flex items-center gap-4 group">
                        <div class="relative flex-shrink-0">
                            <div class="absolute inset-0 bg-emerald-400 rounded-xl blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
                            <div class="relative w-12 h-12 bg-gradient-to-br from-emerald-400 via-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-md ring-2 ring-emerald-50 group-hover:scale-105 transition-transform">
                                <i class="fa-solid fa-user w-6 h-6 text-white flex items-center justify-center"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-xs font-medium text-slate-400 uppercase tracking-wider">Dikelola Oleh</p>
                            <div class="flex items-center gap-2">
                                <h3 class="text-base font-bold text-slate-800 dark:text-white tracking-tight truncate">{{ $webApp->user->name }}</h3>
                                @if($webApp->user->deleted_at)
                                    <span class="px-1.5 py-0.5 text-[10px] font-medium rounded bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">Nonaktif</span>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Link Akses -->
                    <div class="flex items-center gap-4 group">
                        <div class="relative flex-shrink-0">
                            <div class="absolute inset-0 bg-blue-400 rounded-xl blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
                            <div class="relative w-12 h-12 bg-gradient-to-br from-blue-400 via-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-md ring-2 ring-blue-50 group-hover:scale-105 transition-transform">
                                <i class="fa-solid fa-arrow-up-right-from-square w-6 h-6 text-white flex items-center justify-center"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-xs font-medium text-slate-400 uppercase tracking-wider">Link Akses</p>
                            @if($webApp->alamat_tautan)
                                <a href="{{ str_starts_with($webApp->alamat_tautan, 'http') ? $webApp->alamat_tautan : 'http://' . $webApp->alamat_tautan }}" target="_blank" class="text-base font-bold text-indigo-600 hover:text-indigo-800 transition-colors flex items-center gap-1.5 group-hover:underline">
                                    Buka
                                    <i class="fa-solid fa-arrow-up-right-from-square w-3.5 h-3.5 flex items-center justify-center"></i>
                                </a>
                            @else
                                <span class="text-base font-medium text-slate-400 italic">-</span>
                            @endif
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Content Layout -->
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8">
            
            <!-- Main Column (Left) -->
            <div class="xl:col-span-2 space-y-8">
                
                <!-- General Information -->
                <section class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800">
                    <div class="px-6 py-5 border-b border-gray-100 dark:border-zinc-800 flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-500/15 flex items-center justify-center">
                            <i class="fa-solid fa-circle-info w-5 h-5 text-blue-600 dark:text-blue-400 flex items-center justify-center"></i>
                        </div>
                        <div>
                            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Informasi Dasar</h2>
                            <p class="text-xs text-gray-500 dark:text-zinc-500">Gambaran umum aplikasi</p>
                        </div>
                    </div>
                    <div class="p-6">
                        <div class="space-y-6">
                             <div>
                                <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Deskripsi</h3>
                                <div class="bg-gray-50 dark:bg-black/30 rounded-xl p-5 text-gray-700 dark:text-zinc-300 leading-relaxed border border-gray-100 dark:border-zinc-800">
                                    {{ $webApp->deskripsi_singkat ?? 'Belum ada deskripsi yang ditambahkan untuk aplikasi ini.' }}
                                </div>
                            </div>
                            
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Jenis Aplikasi</h3>
                                    <div class="flex items-center">
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-sky-50 dark:bg-sky-500/15 text-sky-700 dark:text-sky-300 border border-sky-100 dark:border-sky-500/25">
                                            <i class="fa-solid fa-desktop w-3.5 h-3.5 mr-1.5 flex items-center justify-center"></i>
                                            {{ $webApp->jenis_aplikasi ?? '-' }}
                                        </span>
                                    </div>
                                </div>
                                <div>
                                <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Alamat Tautan</h3>
                                    <div class="flex items-center text-sm font-medium text-gray-900 min-w-0">
                                        @if($webApp->alamat_tautan)
                                            <i class="fa-solid fa-link w-4 h-4 mr-2 text-gray-400 flex-shrink-0 flex items-center justify-center"></i>
                                            <a href="{{ str_starts_with($webApp->alamat_tautan, 'http') ? $webApp->alamat_tautan : 'http://' . $webApp->alamat_tautan }}" target="_blank" class="text-blue-600 hover:underline break-all">{{ $webApp->alamat_tautan }}</a>
                                        @else
                                            <span class="text-gray-400 italic">Tidak tersedia</span>
                                        @endif
                                    </div>
                                </div>
                                <div>
                                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Arsitektur</h3>
                                     <div class="flex items-center">
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-50 text-purple-700 border border-purple-100">
                                            <i class="fa-solid fa-server w-3.5 h-3.5 mr-1.5 flex items-center justify-center"></i>
                                            @if($webApp->arsitektur_sistem == 'monolith')
                                                Monolith (Satu codebase)
                                            @elseif($webApp->arsitektur_sistem == 'be-fe')
                                                Terpisah (Backend & Frontend)
                                            @else
                                                {{ $webApp->arsitektur_sistem ?? '-' }}
                                            @endif
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Tech Stack -->
                <section class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800">
                    <div class="px-6 py-5 border-b border-gray-100 dark:border-zinc-800 flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-500/15 flex items-center justify-center">
                             <i class="fa-solid fa-code w-5 h-5 text-indigo-600 dark:text-indigo-400 flex items-center justify-center"></i>
                        </div>
                        <div>
                            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Stack Teknologi</h2>
                            <p class="text-xs text-gray-500 dark:text-zinc-500">Framework dan bahasa yang digunakan</p>
                        </div>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <!-- Framework -->
                            <div>
                                <h4 class="text-sm font-semibold text-gray-900 dark:text-zinc-200 mb-3 flex items-center">
                                    <span class="w-1.5 h-1.5 rounded-full bg-indigo-500 mr-2"></span> Framework Utama
                                </h4>
                                @if($webApp->framework)
                                    <div class="flex items-center p-3 bg-gray-50 dark:bg-black/30 rounded-lg border border-gray-100 dark:border-zinc-800">
                                        <div class="flex-1">
                                            <div class="font-bold text-gray-900 dark:text-zinc-200">{{ $webApp->framework }}</div>
                                            @if($webApp->versi_framework)
                                                <div class="text-xs text-gray-500">Versi {{ $webApp->versi_framework }}</div>
                                            @endif
                                        </div>
                                    </div>
                                @else
                                    <span class="text-gray-400 italic text-sm">Tidak ada data</span>
                                @endif
                            </div>

                            <!-- Programming Language -->
                            <div>
                                <h4 class="text-sm font-semibold text-gray-900 dark:text-zinc-200 mb-3 flex items-center">
                                    <span class="w-1.5 h-1.5 rounded-full bg-pink-500 mr-2"></span> Bahasa Pemrograman
                                </h4>
                                @if($webApp->bahasa_pemrograman)
                                    <div class="flex flex-wrap gap-2">
                                        @foreach(explode(',', $webApp->bahasa_pemrograman) as $lang)
                                            <span class="inline-flex items-center px-3 py-1.5 rounded-md text-sm font-medium bg-pink-50 dark:bg-pink-500/12 text-pink-700 dark:text-pink-400 border border-pink-100 dark:border-pink-500/25">
                                                {{ trim($lang) }}
                                            </span>
                                        @endforeach
                                    </div>
                                @else
                                    <span class="text-gray-400 italic text-sm">Tidak ada data</span>
                                @endif
                            </div>

                           <!-- Libraries -->
                           <div class="md:col-span-2">
                                <h4 class="text-sm font-semibold text-gray-900 dark:text-zinc-200 mb-3 flex items-center">
                                    <span class="w-1.5 h-1.5 rounded-full bg-teal-500 mr-2"></span> Libraries / Packages
                                </h4>
                                @if($webApp->daftar_library_package)
                                    <div class="bg-slate-50 dark:bg-black/30 rounded-lg p-4 border border-slate-100 dark:border-zinc-800 font-mono text-sm text-slate-700 dark:text-zinc-300 whitespace-pre-line leading-relaxed">
                                        {{ $webApp->daftar_library_package }}
                                    </div>
                                @else
                                    <div class="p-4 bg-gray-50 dark:bg-black/30 rounded-lg border border-gray-100 dark:border-zinc-800 text-center">
                                        <span class="text-gray-400 dark:text-zinc-600 italic text-sm">Tidak ada daftar library</span>
                                    </div>
                                @endif
                           </div>
                        </div>
                    </div>
                </section>

                <!-- Integration & Security -->
                <section class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800">
                    <div class="px-6 py-5 border-b border-gray-100 dark:border-zinc-800 flex items-center gap-3">
                         <div class="w-10 h-10 rounded-full bg-sky-50 dark:bg-sky-900/20 flex items-center justify-center">
                             <i class="fa-solid fa-shield-halved w-5 h-5 text-sky-600 dark:text-sky-300 flex items-center justify-center"></i>
                        </div>
                        <div>
                            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Integrasi & Keamanan</h2>
                            <p class="text-xs text-gray-500 dark:text-zinc-500">Konektivitas dan protokol backup</p>
                        </div>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 gap-8">
                            
                            <!-- 1. Integrasi Sistem Eksternal -->
                            <div class="relative group">
                                <div class="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-sky-500 to-sky-300 dark:from-sky-600 dark:to-sky-800 rounded-l-full"></div>
                                <div class="pl-2">
                                    <div class="flex items-center mb-3">
                                        <div class="flex items-center justify-center w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300 font-bold text-sm mr-3 shadow-sm border border-sky-200 dark:border-sky-800">1</div>
                                        <h4 class="text-base font-bold text-gray-900 dark:text-zinc-200">Integrasi Sistem Eksternal</h4>
                                    </div>
                                    <div class="bg-sky-50/50 dark:bg-zinc-800/50 rounded-xl p-5 text-sm text-gray-700 dark:text-zinc-300 leading-relaxed border border-sky-100 dark:border-zinc-700/50 whitespace-pre-line shadow-sm hover:shadow-md transition-shadow">
                                        {{ $webApp->integrasi_sistem_keluar ?? 'Tidak ada integrasi dengan sistem luar.' }}
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 2. Metode Monitoring & Evaluasi -->
                            <div class="relative group">
                                <div class="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-sky-500 to-sky-300 dark:from-sky-600 dark:to-sky-800 rounded-l-full"></div>
                                <div class="pl-2">
                                    <div class="flex items-center mb-3">
                                        <div class="flex items-center justify-center w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300 font-bold text-sm mr-3 shadow-sm border border-sky-200 dark:border-sky-800">2</div>
                                        <h4 class="text-base font-bold text-gray-900 dark:text-zinc-200">Metode Monitoring & Evaluasi</h4>
                                    </div>
                                    <div class="bg-sky-50/50 dark:bg-zinc-800/50 rounded-xl p-5 text-sm text-gray-700 dark:text-zinc-300 leading-relaxed border border-sky-100 dark:border-zinc-700/50 whitespace-pre-line shadow-sm hover:shadow-md transition-shadow">
                                        {{ $webApp->metode_monitoring_evaluasi ?? 'Tidak ada data.' }}
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 3, 4 & 5. Backup Section -->
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- 3. Backup Source Code -->
                                <div class="relative group">
                                     <div class="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-sky-500 to-sky-300 dark:from-sky-600 dark:to-sky-800 rounded-l-full"></div>
                                     <div class="pl-2 h-full flex flex-col">
                                        <div class="flex items-center mb-3">
                                            <div class="flex items-center justify-center w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300 font-bold text-sm mr-3 shadow-sm border border-sky-200 dark:border-sky-800">3</div>
                                            <h4 class="text-base font-bold text-gray-900 dark:text-zinc-200">Backup Source Code</h4>
                                        </div>
                                        <div class="bg-sky-50/50 dark:bg-zinc-800/50 rounded-xl p-4 text-sm text-gray-700 dark:text-zinc-300 leading-relaxed border border-sky-100 dark:border-zinc-700/50 whitespace-pre-line shadow-sm hover:shadow-md transition-shadow flex-grow">
                                            {{ $webApp->metode_backup_source_code ?? 'Tidak ada data.' }}
                                        </div>
                                     </div>
                                </div>
                                
                                <!-- 4. Backup Database -->
                                <div class="relative group">
                                    <div class="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-sky-500 to-sky-300 dark:from-sky-600 dark:to-sky-800 rounded-l-full"></div>
                                    <div class="pl-2 h-full flex flex-col">
                                        <div class="flex items-center mb-3">
                                            <div class="flex items-center justify-center w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300 font-bold text-sm mr-3 shadow-sm border border-sky-200 dark:border-sky-800">4</div>
                                            <h4 class="text-base font-bold text-gray-900 dark:text-zinc-200">Backup Database</h4>
                                        </div>
                                        <div class="bg-sky-50/50 dark:bg-zinc-800/50 rounded-xl p-4 text-sm text-gray-700 dark:text-zinc-300 leading-relaxed border border-sky-100 dark:border-zinc-700/50 whitespace-pre-line shadow-sm hover:shadow-md transition-shadow flex-grow">
                                            {{ $webApp->metode_backup_database ?? 'Tidak ada data.' }}
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- 5. Backup Assets (File/Gambar) -->
                                <div class="relative group">
                                    <div class="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-sky-500 to-sky-300 dark:from-sky-600 dark:to-sky-800 rounded-l-full"></div>
                                    <div class="pl-2 h-full flex flex-col">
                                        <div class="flex items-center mb-3">
                                            <div class="flex items-center justify-center w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300 font-bold text-sm mr-3 shadow-sm border border-sky-200 dark:border-sky-800">5</div>
                                            <h4 class="text-base font-bold text-gray-900 dark:text-zinc-200">Backup Assets</h4>
                                        </div>
                                        <div class="bg-sky-50/50 dark:bg-zinc-800/50 rounded-xl p-4 text-sm text-gray-700 dark:text-zinc-300 leading-relaxed border border-sky-100 dark:border-zinc-700/50 whitespace-pre-line shadow-sm hover:shadow-md transition-shadow flex-grow">
                                            {{ $webApp->metode_backup_asset ?? 'Tidak ada data.' }}
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </div>

            <!-- Sidebar (Right) -->
            <div class="space-y-8">
                
                <!-- Team Card -->
                <div class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800 overflow-hidden">
                    <div class="p-5 bg-gray-50 dark:bg-black/30 border-b border-gray-100 dark:border-zinc-800">
                        <h3 class="font-bold text-gray-900 dark:text-white flex items-center">
                            <i class="fa-solid fa-users w-5 h-5 mr-2 text-gray-500 dark:text-zinc-400 flex items-center justify-center"></i>
                            Tim Pengembang
                        </h3>
                    </div>
                    <div class="p-6 space-y-5">
                         <div>
                            <span class="block text-xs font-semibold text-gray-500 dark:text-zinc-500 uppercase mb-2">Data Tim Pengembang</span>
                            <div class="flex items-start gap-3">
                                <div class="bg-blue-100 dark:bg-blue-500/15 p-2 rounded-lg text-blue-600 dark:text-blue-400">
                                    <i class="fa-solid fa-users-gear w-5 h-5 flex items-center justify-center"></i>
                                </div>
                                <div class="text-sm font-medium text-gray-900 dark:text-zinc-200 pt-1 whitespace-pre-line">
                                    {{ $webApp->data_tim_programmer ?? 'Internal Diskominfo' }}
                                </div>
                            </div>
                        </div>
                        
                        <div class="border-t border-gray-100 dark:border-zinc-800 pt-4 space-y-3">
                            <span class="block text-xs font-semibold text-gray-500 dark:text-zinc-500 uppercase mb-2">Kontak Narahubung</span>
                            
                            <!-- Email -->
                            @if($webApp->email_narahubung)
                                <a href="mailto:{{ $webApp->email_narahubung }}" class="flex items-center p-3 rounded-lg bg-blue-50 dark:bg-blue-500/12 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors">
                                    <i class="fa-regular fa-envelope w-4 h-4 mr-2 flex items-center justify-center"></i>
                                    <span class="text-sm font-medium truncate">{{ $webApp->email_narahubung }}</span>
                                </a>
                            @else
                                <span class="text-sm text-gray-400 italic">Tidak ada email kontak</span>
                            @endif
                            
                            <!-- WhatsApp -->
                            @if($webApp->whatsapp_narahubung)
                                @php
                                    $waNumber = preg_replace('/[^0-9]/', '', $webApp->whatsapp_narahubung);
                                    $waNumber = ltrim($waNumber, '0');
                                    $waNumber = '62' . $waNumber;
                                @endphp
                                <a href="https://wa.me/{{ $waNumber }}" target="_blank" class="flex items-center p-3 rounded-lg bg-green-50 dark:bg-green-500/12 text-green-700 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-500/20 transition-colors">
                                    <i class="fa-brands fa-whatsapp w-4 h-4 mr-2 flex items-center justify-center"></i>
                                    <span class="text-sm font-medium">{{ $webApp->whatsapp_narahubung }}</span>
                                    <span class="ml-auto text-[10px] bg-green-200 dark:bg-green-800 px-1.5 py-0.5 rounded">Klik untuk chat</span>
                                </a>
                            @else
                                <span class="text-sm text-gray-400 italic">Tidak ada nomor WhatsApp</span>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Repository -->
                <div class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800 overflow-hidden">
                    <div class="p-5 bg-gray-50 dark:bg-black/30 border-b border-gray-100 dark:border-zinc-800">
                        <h3 class="font-bold text-gray-900 dark:text-white flex items-center">
                            <i class="fa-solid fa-folder-open w-5 h-5 mr-2 text-gray-500 dark:text-zinc-400 flex items-center justify-center"></i>
                            Repository
                        </h3>
                    </div>
                    <div class="p-6 space-y-4">
                        <!-- Has Repository -->
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-gray-600 dark:text-zinc-400">Memiliki Repository</span>
                            @if($webApp->has_repository == 'ya')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-green-50 text-green-700 border border-green-100">
                                    <i class="fa-solid fa-check w-3 h-3 mr-1 flex items-center justify-center"></i>
                                    Ya
                                </span>
                            @elseif($webApp->has_repository == 'tidak')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-gray-100 text-gray-600 border border-gray-200">
                                    <i class="fa-solid fa-xmark w-3 h-3 mr-1 flex items-center justify-center"></i>
                                    Tidak
                                </span>
                            @else
                                <span class="text-sm text-gray-400">-</span>
                            @endif
                        </div>

                        <!-- Access Type (Only show if has_repository = ya) -->
                        @if($webApp->has_repository == 'ya' && $webApp->git_repository)
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-gray-600 dark:text-zinc-400">Akses Repository</span>
                            @if($webApp->git_repository == 'private')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-red-50 text-red-700 border border-red-100">
                                    <i class="fa-solid fa-lock w-3 h-3 mr-1 flex items-center justify-center"></i>
                                    Private
                                </span>
                            @elseif($webApp->git_repository == 'public')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-green-50 text-green-700 border border-green-100">
                                    <i class="fa-solid fa-circle-check w-3 h-3 mr-1 flex items-center justify-center"></i>
                                    Public
                                </span>
                            @endif
                        </div>
                        @endif

                        <!-- Penyedia Repository (Only show if has provider) -->
                        @if($webApp->has_repository == 'ya' && $webApp->penyedia_repository)
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-gray-600 dark:text-zinc-400">Penyedia</span>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                                <i class="fa-solid fa-circle-check w-3 h-3 mr-1 flex items-center justify-center"></i>
                                {{ $webApp->penyedia_repository }}
                            </span>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Infrastructure -->
                <div class="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-gray-200 dark:border-zinc-800 overflow-hidden">
                    <div class="p-5 bg-gray-50 dark:bg-black/30 border-b border-gray-100 dark:border-zinc-800">
                        <h3 class="font-bold text-gray-900 dark:text-white flex items-center">
                             <i class="fa-solid fa-server w-5 h-5 mr-2 text-gray-500 dark:text-zinc-400 flex items-center justify-center"></i>
                            Database & Server
                        </h3>
                    </div>
                    <div class="px-6 py-2">
                        <div class="divide-y divide-gray-100 dark:divide-zinc-800">
                            <!-- DBMS -->
                            <div class="py-3 flex justify-between items-center text-sm">
                                <span class="text-gray-500 dark:text-zinc-400">DBMS</span>
                                <span class="font-medium text-gray-900 dark:text-zinc-200">{{ $webApp->dbms ?? '-' }}</span>
                            </div>
                            <!-- Versi DBMS -->
                            <div class="py-3 flex justify-between items-center text-sm">
                                <span class="text-gray-500 dark:text-zinc-400">Versi DBMS</span>
                                <span class="font-medium text-gray-900 dark:text-zinc-200">{{ $webApp->versi_dbms ?? '-' }}</span>
                            </div>
                            <!-- Location -->
                            <div class="py-3 flex justify-between items-center text-sm">
                                <span class="text-gray-500 dark:text-zinc-400">Lokasi Server DBMS</span>
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold {{ $webApp->lokasi_database == 'Server Kominfo' ? 'bg-blue-50 text-blue-700' : 'bg-gray-100 text-gray-700' }}">
                                    {{ $webApp->lokasi_database == 'Lainnya' ? 'Lainnya (di luar Server Kominfo)' : ($webApp->lokasi_database ?? '-') }}
                                </span>
                            </div>
                             <!-- Access -->
                            <div class="py-3 flex justify-between items-center text-sm">
                                <span class="text-gray-500 dark:text-zinc-400">Akses</span>
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold {{ $webApp->akses_database == 'private' ? 'bg-orange-50 text-orange-700' : 'bg-teal-50 text-teal-700' }}">
                                    {{ ucfirst($webApp->akses_database) ?? '-' }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</x-admin-layout>
