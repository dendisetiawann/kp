<x-admin-layout>
    <x-slot name="header">
        Detail User
    </x-slot>

    <!-- Main Container -->
    <!-- Main Container -->
    <div class="space-y-8">
        
        <!-- Breadcrumb & Actions -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center text-sm font-medium text-gray-500 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400">
                            <i class="fa-solid fa-house w-4 h-4 mr-2 flex items-center justify-center"></i>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fa-solid fa-chevron-right w-6 h-6 text-gray-400 flex items-center justify-center"></i>
                            <a href="{{ route('admin.users.index') }}" class="ml-1 text-sm font-medium text-gray-500 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400 md:ml-2">Manajemen User</a>
                        </div>
                    </li>
                    <li aria-current="page">
                        <div class="flex items-center">
                            <i class="fa-solid fa-chevron-right w-6 h-6 text-gray-400 flex items-center justify-center"></i>
                            <span class="ml-1 text-sm font-medium text-gray-800 dark:text-zinc-200 md:ml-2">{{ Str::limit($user->name, 20) }}</span>
                        </div>
                    </li>
                </ol>
            </nav>
            
            <div class="flex items-center gap-2">
                <a href="{{ route('admin.users.index') }}" class="inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-zinc-700 shadow-sm text-sm font-medium rounded-lg text-gray-700 dark:text-zinc-300 bg-white dark:bg-zinc-900 hover:bg-gray-50 dark:hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors">
                    <i class="fa-solid fa-arrow-left w-4 h-4 mr-2 text-gray-500 flex items-center justify-center"></i>
                    Kembali
                </a>
            </div>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="p-4 bg-green-50 dark:bg-emerald-500/10 border border-green-200 dark:border-emerald-500/25 rounded-xl">
                <div class="flex items-start">
                    <i class="fa-solid fa-circle-check w-5 h-5 text-green-500 mr-3 mt-0.5 flex items-center justify-center"></i>
                    <div>
                        <p class="text-sm font-medium text-green-800 dark:text-emerald-300">{{ session('success') }}</p>
                        @if(str_contains(session('success'), 'password') || str_contains(session('success'), 'Password') || str_contains(session('success'), 'direset'))
                            <p class="text-xs text-green-600 dark:text-emerald-400 mt-1">Salin password ini dan berikan kepada user. Password hanya ditampilkan sekali.</p>
                        @endif
                    </div>
                </div>
            </div>
        @endif

        <!-- Section Title -->
        <div class="mb-4">
            <h2 class="text-xl font-bold text-gray-900 dark:text-white">Informasi Lengkap User</h2>
        </div>

        <!-- User Header Card -->
        <!-- User Header Card -->
        <div class="relative bg-white dark:bg-zinc-900 rounded-2xl shadow-sm dark:shadow-xl border border-sky-100/50 dark:border-zinc-800 p-5 hover:shadow-xl transition-all duration-300 overflow-hidden group">
            <!-- Subtle Wave Background -->
            <div class="absolute inset-0 opacity-5 dark:opacity-[0.03]">
                <div class="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-cyan-400 via-sky-300 to-transparent"></div>
            </div>
            
            <div class="relative flex flex-col md:flex-row items-center gap-5 z-10">
                <!-- Avatar Section -->
                <div class="flex-shrink-0 relative group-hover:scale-105 transition-transform duration-500">
                    <div class="absolute inset-0 bg-sky-400 rounded-2xl blur-xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
                    @if($user->profile_photo)
                        <img src="{{ asset('storage/' . $user->profile_photo) }}" alt="{{ $user->name }}" class="relative h-20 w-20 rounded-xl object-cover ring-4 ring-white shadow-lg">
                    @else
                        <div class="relative h-20 w-20 rounded-xl bg-gradient-to-br from-sky-400 via-sky-500 to-blue-500 flex items-center justify-center text-white font-black text-3xl ring-4 ring-white shadow-lg">
                            {{ strtoupper(substr($user->name, 0, 1)) }}
                        </div>
                    @endif
                </div>
                
                <!-- Vertical Separator -->
                <div class="hidden md:block w-px h-24 bg-gradient-to-b from-transparent via-slate-200 dark:via-zinc-700 to-transparent"></div>

                <!-- User Info -->
                <div class="flex-1 min-w-0 w-full">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                        
                        <!-- Nama Lengkap (Match Total Aplikasi Style) -->
                        <div class="flex items-center gap-5 group/item">
                            <div class="flex-1 min-w-0">
                                <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Nama Lengkap</p>
                                <h3 class="text-xl font-black text-slate-800 dark:text-white tracking-tight leading-tight">{{ $user->name }}</h3>
                                <p class="text-sm text-slate-500 dark:text-zinc-400 font-medium mt-1 transition-colors group-hover/item:text-blue-500">{{ $user->email }}</p>
                            </div>
                        </div>

                        <!-- OPD (Match Total OPD Style) -->
                        <div class="flex items-center gap-5 group/item">
                            <div class="relative flex-shrink-0">
                                <div class="absolute inset-0 bg-cyan-400 rounded-2xl blur-xl opacity-0 group-hover/item:opacity-30 transition-opacity"></div>
                                <div class="relative w-14 h-14 bg-gradient-to-br from-cyan-400 via-sky-500 to-sky-600 rounded-xl flex items-center justify-center shadow-lg ring-2 ring-cyan-50 group-hover/item:scale-105 transition-transform">
                                    <i class="fa-solid fa-building w-7 h-7 text-white flex items-center justify-center"></i>
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Organisasi Perangkat Daerah</p>
                                <h3 class="text-lg font-black text-slate-800 dark:text-white tracking-tight leading-tight">{{ $user->opd->nama_opd ?? 'Belum ada OPD' }}</h3>
                            </div>
                        </div>

                        <!-- Action Buttons (Aligned with OPD, stacked vertically) -->
                        <div class="flex flex-col items-center gap-2">
                            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 text-center">Aksi</p>
                            <div class="flex flex-col gap-2 w-auto">
                                <button type="button" onclick="document.getElementById('updateEmailModal').classList.remove('hidden')" class="inline-flex items-center justify-center w-full px-3 py-1.5 bg-blue-500 border border-transparent shadow-sm text-xs font-medium rounded-lg text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors whitespace-nowrap">
                                    <i class="fa-regular fa-envelope w-3.5 h-3.5 mr-1.5 flex items-center justify-center"></i>
                                    Ubah Email
                                </button>
                                <button type="button" onclick="document.getElementById('resetPasswordModal').classList.remove('hidden')" class="inline-flex items-center justify-center w-full px-3 py-1.5 bg-amber-500 border border-transparent shadow-sm text-xs font-medium rounded-lg text-white hover:bg-amber-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors whitespace-nowrap">
                                    <i class="fa-solid fa-key w-3.5 h-3.5 mr-1.5 flex items-center justify-center"></i>
                                    Reset Password
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards Row -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <!-- Bergabung Sejak -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 p-5">
                <div class="flex items-center gap-3">
                    <div class="p-3 bg-blue-50 rounded-xl">
                        <i class="fa-regular fa-calendar w-6 h-6 text-blue-600 flex items-center justify-center"></i>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 uppercase tracking-wide font-medium">Bergabung Sejak</p>
                        <p class="text-lg font-bold text-gray-900">{{ $user->created_at->format('d M Y') }}</p>
                        <p class="text-xs text-gray-400">{{ $user->created_at->diffForHumans() }}</p>
                    </div>
                </div>
            </div>

            <!-- Terakhir Input Aplikasi -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 p-5">
                <div class="flex items-center gap-3">
                    <div class="p-3 bg-emerald-50 rounded-xl">
                        <i class="fa-solid fa-plus w-6 h-6 text-emerald-600 flex items-center justify-center"></i>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 uppercase tracking-wide font-medium">Terakhir Input Aplikasi</p>
                        @if($lastAppInput)
                            <p class="text-lg font-bold text-gray-900">{{ $lastAppInput->created_at->format('d M Y') }}</p>
                            <p class="text-xs text-gray-400">{{ $lastAppInput->created_at->diffForHumans() }}</p>
                        @else
                            <p class="text-lg font-bold text-gray-400">Belum ada</p>
                            <p class="text-xs text-gray-400">-</p>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Total Aplikasi -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 p-5">
                <div class="flex items-center gap-3">
                    <div class="p-3 bg-indigo-50 rounded-xl">
                        <i class="fa-solid fa-pen-to-square w-6 h-6 text-indigo-600 flex items-center justify-center"></i>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 uppercase tracking-wide font-medium">Total Aplikasi</p>
                        <p class="text-lg font-bold text-gray-900">{{ $totalApps }} Aplikasi</p>
                        <p class="text-xs text-gray-400">Terdaftar di sistem</p>
                    </div>
                </div>
            </div>

            <!-- Status Akun -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 p-5">
                <div class="flex items-center gap-3">
                    <div class="p-3 bg-green-50 rounded-xl">
                        <i class="fa-solid fa-circle-check w-6 h-6 text-green-600 flex items-center justify-center"></i>
                    </div>
                    <div class="flex-1">
                        <p class="text-xs text-gray-500 uppercase tracking-wide font-medium">Terakhir Login</p>
                        @if($user->last_login_at)
                            <p class="text-sm font-bold text-gray-900">{{ $user->last_login_at->format('d M Y, H:i') }}</p>
                            <p class="text-xs text-gray-400">{{ $user->last_login_device ?? 'Unknown device' }}</p>
                        @else
                            <p class="text-sm font-bold text-gray-400">Belum pernah login</p>
                            <p class="text-xs text-gray-400">-</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Detail Info Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Informasi Akun -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-zinc-800 bg-gray-50/50 dark:bg-black/30">
                    <h3 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <i class="fa-solid fa-user w-5 h-5 text-blue-600 dark:text-blue-400 flex items-center justify-center"></i>
                        Informasi Akun
                    </h3>
                </div>
                <div class="p-6">
                    <dl class="space-y-4">
                        <div class="flex justify-between items-start">
                            <dt class="text-sm text-gray-500">ID User</dt>
                            <dd class="text-sm font-mono text-gray-900 bg-gray-100 px-2 py-1 rounded">#{{ $user->id }}</dd>
                        </div>
                        <div class="flex justify-between items-start">
                            <dt class="text-sm text-gray-500">Nama Lengkap</dt>
                            <dd class="text-sm font-semibold text-gray-900">{{ $user->name }}</dd>
                        </div>
                        <div class="flex justify-between items-start">
                            <dt class="text-sm text-gray-500">Email</dt>
                            <dd class="text-sm text-gray-900">{{ $user->email }}</dd>
                        </div>
                        <div class="flex justify-between items-start">
                            <dt class="text-sm text-gray-500">Role</dt>
                            <dd>
                                <span class="px-2.5 py-1 text-xs font-semibold rounded-full {{ $user->role === 'admin' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700' }}">
                                    {{ ucfirst($user->role) }}
                                </span>
                            </dd>
                        </div>

                        <div class="pt-3 mt-3 border-t border-gray-100 dark:border-zinc-800">
                            <p class="text-xs text-gray-400 uppercase tracking-wide font-medium mb-3">Aktivitas Login Terakhir</p>
                            <div class="space-y-2">
                                <div class="flex justify-between items-start">
                                    <dt class="text-sm text-gray-500">Waktu Login</dt>
                                    <dd class="text-sm text-gray-900">
                                        @if($user->last_login_at)
                                            {{ $user->last_login_at->format('d M Y, H:i:s') }}
                                        @else
                                            <span class="text-gray-400">Belum pernah login</span>
                                        @endif
                                    </dd>
                                </div>
                                <div class="flex justify-between items-start">
                                    <dt class="text-sm text-gray-500">IP Address</dt>
                                    <dd class="text-sm font-mono text-gray-900 bg-gray-100 px-2 py-0.5 rounded text-xs">
                                        {{ $user->last_login_ip ?? '-' }}
                                    </dd>
                                </div>
                                <div class="flex justify-between items-start">
                                    <dt class="text-sm text-gray-500">Device / Browser</dt>
                                    <dd class="text-sm text-gray-900 text-right max-w-[180px]">
                                        {{ $user->last_login_device ?? '-' }}
                                    </dd>
                                </div>
                            </div>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Informasi OPD -->
            <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-sm dark:shadow-xl border border-gray-100 dark:border-zinc-800 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-zinc-800 bg-gray-50/50 dark:bg-black/30">
                    <h3 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <i class="fa-solid fa-building w-5 h-5 text-cyan-600 dark:text-cyan-400 flex items-center justify-center"></i>
                        Informasi OPD
                    </h3>
                </div>
                <div class="p-6">
                    @if($user->opd)
                        <dl class="space-y-4">
                            <div class="flex justify-between items-start">
                                <dt class="text-sm text-gray-500">ID OPD</dt>
                                <dd class="text-sm font-mono text-gray-900 bg-gray-100 px-2 py-1 rounded">#{{ $user->opd->id }}</dd>
                            </div>
                            <div class="flex justify-between items-start">
                                <dt class="text-sm text-gray-500">Nama OPD</dt>
                                <dd class="text-sm font-semibold text-gray-900 text-right max-w-[200px]">{{ $user->opd->nama_opd }}</dd>
                            </div>

                            <div class="flex justify-between items-start">
                                <dt class="text-sm text-gray-500">Total Seluruh Aplikasi (Pada OPD Ini)</dt>
                                <dd class="text-sm font-bold text-indigo-600">{{ $totalApps }} Aplikasi</dd>
                            </div>
                        </dl>
                    @else
                        <p class="text-sm text-gray-500 text-center py-4">Tidak ada data OPD</p>
                    @endif
                </div>
            </div>
        </div>

    <!-- Reset Password Modal -->
    <div id="resetPasswordModal" class="hidden fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <!-- Background overlay -->
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onclick="document.getElementById('resetPasswordModal').classList.add('hidden')"></div>

            <!-- Modal panel -->
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white px-6 pt-6 pb-4">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="p-2 bg-amber-100 rounded-xl">
                                <i class="fa-solid fa-key w-6 h-6 text-amber-600 flex items-center justify-center"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-gray-900">Reset Password</h3>
                                <p class="text-sm text-gray-500">{{ $user->name }}</p>
                            </div>
                        </div>
                        <button type="button" onclick="document.getElementById('resetPasswordModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-500">
                            <i class="fa-solid fa-xmark w-6 h-6 flex items-center justify-center"></i>
                        </button>
                    </div>
                    
                    <form action="{{ route('admin.users.reset-password', $user) }}" method="POST">
                        @csrf
                        
                        <div class="space-y-3 mb-4">
                            <label class="flex items-center p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                                <input type="radio" name="password_type" value="random" class="h-4 w-4 text-amber-600 focus:ring-amber-500" checked onchange="toggleCustomPassword()">
                                <div class="ml-3">
                                    <span class="block text-sm font-medium text-gray-900">Generate Random</span>
                                    <span class="block text-xs text-gray-500">Password acak 8 karakter</span>
                                </div>
                            </label>
                            <label class="flex items-center p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                                <input type="radio" name="password_type" value="custom" class="h-4 w-4 text-amber-600 focus:ring-amber-500" onchange="toggleCustomPassword()">
                                <div class="ml-3">
                                    <span class="block text-sm font-medium text-gray-900">Custom Password</span>
                                    <span class="block text-xs text-gray-500">Tentukan password manual</span>
                                </div>
                            </label>
                        </div>

                        <div id="customPasswordSection" class="mb-4 hidden">
                            <input type="text" name="custom_password" id="custom_password" 
                                class="w-full border-gray-300 focus:border-amber-500 focus:ring-amber-500 rounded-lg shadow-sm"
                                placeholder="Minimal 8 karakter">
                        </div>

                        <div class="flex gap-3 pt-2">
                            <button type="button" onclick="document.getElementById('resetPasswordModal').classList.add('hidden')" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                                Batal
                            </button>
                            <button type="button" onclick="document.getElementById('confirmResetPasswordPopup').classList.remove('hidden')" class="flex-1 px-4 py-2.5 bg-amber-500 rounded-lg text-sm font-semibold text-white hover:bg-amber-600 transition-colors">
                                Reset Password
                            </button>
                        </div>

                        <!-- Confirmation Popup -->
                        <div id="confirmResetPasswordPopup" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4">
                            <div class="absolute inset-0 bg-black/50" onclick="document.getElementById('confirmResetPasswordPopup').classList.add('hidden')"></div>
                            <div class="relative bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 transform transition-all">
                                <div class="text-center">
                                    <div class="mx-auto w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mb-4">
                                        <i class="fa-solid fa-circle-exclamation w-8 h-8 text-red-500 flex items-center justify-center"></i>
                                    </div>
                                    <h3 class="text-lg font-bold text-gray-900 mb-2">Konfirmasi Reset Password</h3>
                                    <p class="text-sm text-gray-600 mb-6">Yakin reset password untuk <strong class="text-gray-900">{{ $user->name }}</strong>?</p>
                                    <div class="flex gap-3">
                                        <button type="button" onclick="document.getElementById('confirmResetPasswordPopup').classList.add('hidden')" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                                            Batal
                                        </button>
                                        <button type="submit" class="flex-1 px-4 py-2.5 bg-red-500 rounded-lg text-sm font-semibold text-white hover:bg-red-600 transition-colors">
                                            Ya, Reset
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Update Email Modal -->
    <div id="updateEmailModal" class="hidden fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <!-- Background overlay -->
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onclick="document.getElementById('updateEmailModal').classList.add('hidden')"></div>

            <!-- Modal panel -->
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white px-6 pt-6 pb-4">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="p-2 bg-blue-100 rounded-xl">
                                <i class="fa-regular fa-envelope w-6 h-6 text-blue-600 flex items-center justify-center"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-gray-900">Ubah Email</h3>
                                <p class="text-sm text-gray-500">{{ $user->name }}</p>
                            </div>
                        </div>
                        <button type="button" onclick="document.getElementById('updateEmailModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-500">
                            <i class="fa-solid fa-xmark w-6 h-6 flex items-center justify-center"></i>
                        </button>
                    </div>
                    
                    <!-- Security Warning -->
                    <div class="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
                        <i class="fa-solid fa-circle-exclamation w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5"></i>
                        <div>
                            <p class="text-xs font-bold text-amber-800">Perhatian</p>
                            <p class="text-xs text-amber-700">Perubahan email akan dicatat dalam log aktivitas untuk keamanan.</p>
                        </div>
                    </div>
                    
                    <form action="{{ route('admin.users.update-email', $user) }}" method="POST">
                        @csrf
                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Email Saat Ini</label>
                            <div class="w-full px-3 py-2 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-600">
                                {{ $user->email }}
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="new_email" class="block text-sm font-medium text-gray-700 mb-1">Email Baru</label>
                            <input type="email" name="new_email" id="new_email" required
                                class="w-full border-gray-300 focus:border-blue-500 focus:ring-blue-500 rounded-lg shadow-sm"
                                placeholder="Masukkan email baru">
                            @error('new_email')
                                <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="flex gap-3 pt-2">
                            <button type="button" onclick="document.getElementById('updateEmailModal').classList.add('hidden')" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                                Batal
                            </button>
                            <button type="button" onclick="showUpdateEmailConfirm()" class="flex-1 px-4 py-2.5 bg-blue-500 rounded-lg text-sm font-semibold text-white hover:bg-blue-600 transition-colors">
                                Simpan Perubahan
                            </button>
                        </div>

                        <!-- Confirmation Popup -->
                        <div id="confirmUpdateEmailPopup" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4">
                            <div class="absolute inset-0 bg-black/50" onclick="document.getElementById('confirmUpdateEmailPopup').classList.add('hidden')"></div>
                            <div class="relative bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 transform transition-all">
                                <div class="text-center">
                                    <div class="mx-auto w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                                        <i class="fa-regular fa-envelope w-8 h-8 text-blue-500 flex items-center justify-center"></i>
                                    </div>
                                    <h3 class="text-lg font-bold text-gray-900 mb-2">Konfirmasi Ubah Email</h3>
                                    <p class="text-sm text-gray-600 mb-6">Yakin ubah email untuk <strong class="text-gray-900">{{ $user->name }}</strong>?</p>
                                    <div class="flex gap-3">
                                        <button type="button" onclick="document.getElementById('confirmUpdateEmailPopup').classList.add('hidden')" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                                            Batal
                                        </button>
                                        <button type="submit" class="flex-1 px-4 py-2.5 bg-blue-600 rounded-lg text-sm font-semibold text-white hover:bg-blue-700 transition-colors">
                                            Ya, Ubah
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleCustomPassword() {
            const customSection = document.getElementById('customPasswordSection');
            const customRadio = document.querySelector('input[name="password_type"][value="custom"]');
            
            if (customRadio.checked) {
                customSection.classList.remove('hidden');
            } else {
                customSection.classList.add('hidden');
            }
        }

        // Update Email Confirmation - validates email first then shows popup
        function showUpdateEmailConfirm() {
            const emailInput = document.getElementById('new_email');
            if (!emailInput.value || !emailInput.checkValidity()) {
                emailInput.reportValidity();
                return;
            }
            document.getElementById('confirmUpdateEmailPopup').classList.remove('hidden');
        }

        // Auto-open modal if there's validation error
        @if($errors->has('new_email'))
            document.getElementById('updateEmailModal').classList.remove('hidden');
        @endif
    </script>
</x-admin-layout>
