<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateWebAppRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            // Informasi Umum
            'nama_web_app' => 'required|string|max:255',
            'deskripsi_singkat' => 'nullable|string',
            'alamat_tautan' => 'required|string|max:255',
            'jenis_aplikasi' => 'nullable|string|max:100',
            
            // Tim & Kontak
            'data_tim_programmer' => 'nullable|string',
            'email_narahubung' => 'nullable|string|max:255',
            'whatsapp_narahubung' => 'nullable|string|max:255',
            
            // Stack Teknologi
            'bahasa_pemrograman' => 'required|string',
            'arsitektur_sistem' => 'required|in:monolith,be-fe',
            'framework' => 'required|string|max:255',
            // 'versi_framework' => 'required|string|max:50', // Deprecated
            'daftar_library_package' => 'nullable|string',
            
            // Repository & Backup
            'has_repository' => 'nullable|in:ya,tidak',
            'git_repository' => 'nullable|in:public,private',
            'penyedia_repository' => 'nullable|string|max:100',
            'metode_backup_source_code' => 'nullable|string',
            'metode_backup_asset' => 'nullable|string',
            
            // Database
            'dbms' => 'nullable|string|max:100',
            'versi_dbms' => 'nullable|string|max:50',
            'lokasi_database' => 'nullable|in:Server Kominfo,Lainnya',
            'akses_database' => 'nullable|in:public,private',
            'metode_backup_database' => 'nullable|string',
            
            // Integrasi & Monev
            'integrasi_sistem_keluar' => 'nullable|string',
            'metode_monitoring_evaluasi' => 'nullable|string',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            // Informasi Umum
            'nama_web_app.required' => 'Nama aplikasi wajib diisi.',
            'nama_web_app.max' => 'Nama aplikasi maksimal 255 karakter.',
            'alamat_tautan.required' => 'Alamat tautan/URL wajib diisi.',
            'alamat_tautan.max' => 'Alamat tautan maksimal 255 karakter.',
            
            // Stack Teknologi
            'bahasa_pemrograman.required' => 'Bahasa pemrograman wajib diisi (tambahkan minimal satu).',
            'arsitektur_sistem.required' => 'Arsitektur sistem wajib dipilih.',
            'arsitektur_sistem.in' => 'Arsitektur sistem harus Monolith atau Backend-Frontend.',
            'framework.required' => 'Framework wajib diisi (tambahkan minimal satu).',
            'daftar_library_package.required' => 'Library/Package wajib diisi (tambahkan minimal satu).',
            
            // Repository & Backup
            'has_repository.in' => 'Pilihan repository harus Ya atau Tidak.',
            'git_repository.in' => 'Status repository harus Public atau Private.',
            
            // Database
            'lokasi_database.in' => 'Lokasi DBMS harus Server Kominfo atau Lainnya.',
            'akses_database.in' => 'Akses database harus Public atau Private.',
        ];
    }
}
